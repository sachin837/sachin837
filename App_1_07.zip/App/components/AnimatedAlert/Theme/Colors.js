export default {
  white: 'white',
  black: 'black',
  transparent: 'transparent',

  //grayShade
  grayShadeA9: '#A9A9A9',
};

export default {
  bell: require('../Resources/Images/bell.png'),
};

import Alert from './Alert/Alert';
export default Alert;
module.exports = Alert;

//react-native-animated-alert